package org.tendiwa.fake;

/**
 * Hello world!
 * @version $tested-token$
 */
public class App {
    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
    }
}

package org.tendiwa.fake;

/**
 * Hello world!
 * @version $version-stub$
 * @since $custom-stub$
 */
public class App {
    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
    }
}
